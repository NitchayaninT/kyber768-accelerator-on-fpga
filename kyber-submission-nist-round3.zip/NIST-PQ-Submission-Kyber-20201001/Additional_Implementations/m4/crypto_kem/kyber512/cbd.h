#ifndef CBD_H
#define CBD_H

#include "poly.h"

void cbd_eta1(poly *r, const unsigned char *buf, int add);
void cbd_eta2(poly *r, const unsigned char *buf, int add);

#endif
