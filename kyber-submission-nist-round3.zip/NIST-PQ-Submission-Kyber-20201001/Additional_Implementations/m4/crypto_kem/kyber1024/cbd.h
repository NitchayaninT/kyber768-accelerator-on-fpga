#ifndef CBD_H
#define CBD_H

#include "poly.h"

void cbd(poly *r, const unsigned char *buf, int add);

#endif
